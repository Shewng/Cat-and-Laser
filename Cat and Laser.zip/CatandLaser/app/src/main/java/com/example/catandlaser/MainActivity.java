package com.example.catandlaser;


import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.graphics.Path;
import android.view.animation.TranslateAnimation;
import android.animation
import android.animation.ObjectAnimator;
import android.view.animation.Animation;
import android.widget.TextView;
import android.util.DisplayMetrics;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    // Variables
    // General variables
    private DisplayMetrics displayMetrics = new DisplayMetrics();

    // Sensor variables
    private SensorManager sensorManager;
    private Sensor light;

    // Values
    private TextView luxValue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        luxValue = (TextView) findViewById(R.id.textView);

        // Get an instance of the sensor service, then use that to get an instance of the light sensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        light = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        hideStatusBar();
        moveRandomly();
    }

    /**
     * Registers a listener for the sensor
     */
    @Override
    protected void onResume() {
        // Register a listener for the sensor
        super.onResume();
        sensorManager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);
    }

    /**
     * Unregisters the sensor when the activity pauses (i.e. outside of the app)
     */
    @Override
    protected void onPause() {
        // Unregister the sensor when the activity pauses
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    /**
     * Detect any change to the sensor itself and react accordingly
     * @param sensor The sensor which is currently being detected
     * @param accuracy The accuracy of the sensor detection(?)
     */
    @Override
    public final void onAccuracyChanged(Sensor sensor, int accuracy)  {
        // Do something here if the sensor changes
        // Put this somewhere - if accuracy == 0, then the dot stops moving and disappears
    }

    /**
     * Detects any change to the sensor's data and react accordingly
     * @param event The event that occurs when the sensor is changed
     */
    @Override
    public final void onSensorChanged(SensorEvent event) {
        float lux = event.values[0];
        //luxValue.clearAnimation();
        luxValue.setText("Lux value: " + lux);

        // Do something with the sensor data, lux
        if (event.sensor.getType() == Sensor.TYPE_LIGHT) {

            // Check if lux is low enough (i.e. covering it with your finger)
            if (lux > 0 && lux < 10) {
                luxValue.setVisibility(View.INVISIBLE);     // Hide the laser

                // >>>>>>>> IMPROTANT <<<<<<<<<<<<
                // Create a new method called like "resetAnim", which gets the current position
                // of the laser (X and Y pixel or w.e), stops the animation, and plays a new one
                // with random values. simulate the random movement.

            } else {
                luxValue.setVisibility(View.VISIBLE);       // Show the laser
            }
        }
    }

    /**
     * Hides the system and navigation bars of the phone to allow for fullscreen
     */
    private void hideStatusBar() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                      | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

    /**
     * Randomly move the laser around the screen.
     * The laser must stay within the boundaries of the phone.
     */
    public void moveRandomly() {
        /*
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation anim) {

            }
        });
        */
        FlingAnimation flingAnimation = new FlingAnimation(luxValue, DynamicAnimation.X);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Path path = new Path();
            path.arcTo(0f, 0f, 1000f, 1000f, 270f, -359f, true);
            ObjectAnimator animator = ObjectAnimator.ofFloat(luxValue, luxValue.X, luxValue.Y, path);
            animator.setDuration(5000);
            animator.setRepeatCount(Animation.INFINITE);
            //animator.start();
        }

        Random rand = new Random();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;

        int transX = rand.nextInt(width - 50);
        int transY = rand.nextInt(height - 75);

        int currentL = luxValue.getLeft();
        int currentT = luxValue.getTop();

        TranslateAnimation anim = new TranslateAnimation(currentL, transX, currentT, transY);
        anim.setDuration(5000);
        anim.setFillAfter(true);
        //luxValue.startAnimation(anim);


        //ObjectAnimator animation = ObjectAnimator.ofFloat(praiseBtn, "translationX", 100f);
        //animation.setDuration(7000);
        //animation.start();

    }


}
